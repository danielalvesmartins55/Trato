# Trato — programa on-chain (MVP)

Pagamentos protegidos (escrow) e trocas OTC atômicas na Solana, escritos em Rust com Anchor 1.2.2.

- **Programa:** `programs/trato/src/lib.rs` (arquivo único, comentado em português)
- **Testes:** `tests-litesvm/tests/flows.rs` (24 testes de integração rodando o programa compilado num simulador da Solana) + 3 testes de taxa dentro do programa
- **Program ID de desenvolvimento:** `7GGLHC2T67tbCwgxQ2ZYXouehHA38UYzqsmgbJ9Ho4mS` (o Solana Playground troca pelo seu automaticamente)

---

## O que o programa faz

### Modo 1: escrow de serviço/produto

| Instrução | Quem assina | O que faz |
|---|---|---|
| `create_deal` | Vendedor | Cria a cobrança (valor, quem paga a taxa, hash dos termos, prazos). Comprador fixo ou link aberto. |
| `fund_deal` | Comprador | Deposita o valor (+ a parte dele da taxa) no cofre. |
| `mark_delivered` | Vendedor | Informa a entrega; começa o prazo de revisão. |
| `release` | Comprador | Libera o pagamento ao vendedor (também encerra uma disputa a favor dele). |
| `claim_after_review` | Vendedor | Recebe sozinho se o comprador não reclamar no prazo de revisão. |
| `refund_after_deadline` | Comprador | Recebe tudo de volta se o vendedor não entregar no prazo. Sem taxa. |
| `seller_refund` | Vendedor | Devolve tudo ao comprador (inclusive cedendo uma disputa). Sem taxa. |
| `cancel_deal` | Vendedor | Cancela uma cobrança ainda não paga. |
| `open_dispute` | Comprador ou vendedor | Abre disputa (o comprador só antes do fim do prazo de revisão). |
| `resolve_dispute` | Árbitro | Decide a divisão em pontos-base (`seller_bps`: 10000 = tudo ao vendedor). |
| `resolve_stale_dispute` | Comprador ou vendedor | Se o árbitro não agir em 30 dias: divisão 50/50 sem nenhuma taxa. |

### Modo 2: troca OTC atômica

| Instrução | Quem assina | O que faz |
|---|---|---|
| `create_otc` | Maker | Deposita o token oferecido e define o que quer em troca, o prazo e (opcional) um taker específico. Um dos lados precisa ser moeda aprovada (USDC/USDT). |
| `take_otc` | Taker | Paga e recebe na mesma transação. Sem árbitro, sem disputa. |
| `cancel_otc` | Maker | Cancela e recebe os tokens de volta (funciona mesmo com o sistema pausado). |

### Administração

| Instrução | Para quê |
|---|---|
| `initialize_config` | Configuração inicial. **Só a autoridade de upgrade do programa** pode chamar (ninguém consegue se adiantar). |
| `update_config` | Muda taxas, árbitro, tesouraria e admin. Use um multisig (Squads) como admin. |
| `set_paused` | Pausa de emergência: bloqueia só operações novas. Saques e reembolsos sempre funcionam. |
| `upsert_mint` | Aprova/ajusta/desativa uma moeda e define limites (mínimo, máximo, taxa mínima). |

### Reputação (base para os pontos)

Cada carteira tem uma conta pública `Reputation` com: negócios como vendedor e como comprador, trocas OTC, disputas ganhas e perdidas, volume e **taxas efetivamente pagas** (difícil de "farmar" sem custo real).

---

## Taxas

| Taxa | Configuração sugerida | Teto no código |
|---|---|---|
| Escrow | 1% (`fee_bps = 100`), mínimo de US$ 0,25 | 2% |
| OTC | 0,5% (`otc_fee_bps = 50`) | 2% |
| Disputa (paga por quem perde) | 2% (`dispute_fee_bps = 200`), mínimo de US$ 0,50 | 5% |

- A taxa de escrow fica travada no momento da criação do negócio.
- Quem paga a taxa: `Seller` (vendedor), `Buyer` (comprador) ou `Split` (dividida).
- Reembolsos não pagam taxa. Em disputas, a taxa de escrow incide só sobre a parte que vai ao vendedor.
- Todo arredondamento favorece o usuário.
- O aluguel (rent) das contas é pago por quem cria e volta para ele no encerramento.

---

## Segurança (decisões do MVP)

- **Só tokens clássicos (SPL Token)**, como USDC e USDT. O Token-2022 ficou de fora porque extensões como *permanent delegate* permitiriam ao emissor retirar tokens de qualquer conta, um golpe possível na troca OTC.
- **Doações não travam negócios:** se alguém enviar tokens direto a um cofre, o programa continua funcionando. A sobra vai para a tesouraria (ou para o vendedor, num cancelamento, ou para o taker, numa troca OTC).
- **Limites por moeda** (ex.: máximo de US$ 500 por negócio no beta) até a auditoria.
- **Só dados mínimos on-chain.** Os termos do acordo entram como hash (`terms_hash`); o documento fica fora da blockchain. **Nunca** grave dados pessoais on-chain (LGPD).
- **Pausa nunca prende dinheiro.**
- **Disputas têm saída automática** (50/50 após 30 dias sem decisão).

**Pendências antes de dinheiro real em volume:** auditoria externa, admin e tesouraria num multisig (Squads) com *time lock* para mudanças de taxa, e o código aberto com *verified build*.

---

## Como rodar no Solana Playground (sem instalar nada)

1. Acesse **https://beta.solpg.io** e crie um projeto novo: nome `trato`, framework **Anchor**, versão **1.2.2**.
2. Substitua todo o conteúdo de `src/lib.rs` pelo arquivo `programs/trato/src/lib.rs` deste pacote.
3. No canto inferior esquerdo, clique para conectar. O Playground cria uma carteira de testes. **Salve o backup da chave** que ele oferece.
4. Confira se a rede é **devnet** (ícone de engrenagem, ou `solana config set --url devnet` no terminal do Playground).
5. Pegue SOL de teste. O deploy precisa de cerca de **6 SOL de devnet** por alguns minutos (metade volta ao fim do deploy):
   - no terminal do Playground: `solana airdrop 2` (repita se precisar; há limite de frequência);
   - ou em **https://faucet.solana.com** (cole o endereço da carteira do Playground).
6. Clique em **Build** e depois em **Deploy**.
7. Na aba **Test**, chame `initialize_config` com:
   - `arbiter` e `treasury`: o endereço da sua carteira (por enquanto);
   - `fee_bps = 100`, `otc_fee_bps = 50`, `dispute_fee_bps = 200`.
8. Ainda na aba Test, chame `upsert_mint` com o **USDC de devnet da Circle**:
   - `mint`: `4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU`
   - `min_amount = 1000000` (US$ 1), `max_amount = 500000000` (US$ 500), `min_fee = 250000` (US$ 0,25), `dispute_min_fee = 500000` (US$ 0,50), `enabled = true`.
9. Pegue USDC de teste em **https://faucet.circle.com** (rede Solana Devnet) para testar os fluxos.

O site (criar link, pagar, painel) é a próxima etapa e vai conversar com este programa.

---

## Como rodar no computador (opcional, para quem for programar)

No Windows, instale primeiro o **WSL** (PowerShell como administrador: `wsl --install`) e faça o resto dentro do Ubuntu.

```bash
# Rust, Solana CLI e Anchor (instalador oficial do Anchor)
curl --proto '=https' --tlsv1.2 -sSfL https://solana-install.solana.workers.dev | bash

anchor --version     # deve mostrar 1.2.x
anchor build         # compila e gera o IDL (target/idl/trato.json)

# testes de integração (simulador LiteSVM)
cd tests-litesvm && cargo test

# deploy na devnet
solana config set --url devnet
solana airdrop 2
anchor deploy
```

Tamanho atual do programa compilado: cerca de **407 KB**, o que exige um depósito (rent) de aproximadamente **2,84 SOL** na mainnet. O depósito é recuperável se o programa for fechado.
