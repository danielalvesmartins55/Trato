//! Testes de integração do Trato rodando o programa compilado (trato.so)
//! num simulador da Solana. Cobrem os fluxos de escrow, disputa, OTC e as
//! proteções (pausa, limites, permissões, prazos).

use borsh::{BorshDeserialize, BorshSerialize};
use litesvm::LiteSVM;
use sha2::{Digest, Sha256};
use solana_account::Account;
use solana_address::Address;
use solana_clock::Clock;
use solana_instruction::{AccountMeta, Instruction};
use solana_keypair::Keypair;
use solana_message::Message;
use solana_signer::Signer;
use solana_transaction::Transaction;

type Pubkey = Address;

const USD: u64 = 1_000_000;
const DAY: i64 = 86_400;
const HOUR: i64 = 3_600;

fn program_id() -> Pubkey {
    "7GGLHC2T67tbCwgxQ2ZYXouehHA38UYzqsmgbJ9Ho4mS".parse().unwrap()
}
fn token_program() -> Pubkey {
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA".parse().unwrap()
}
fn system_program() -> Pubkey {
    Pubkey::default()
}
fn loader_v3() -> Pubkey {
    "BPFLoaderUpgradeab1e11111111111111111111111".parse().unwrap()
}

// ----------------------------- Codificação Anchor -----------------------------

fn sighash(name: &str) -> [u8; 8] {
    let h = Sha256::digest(format!("global:{name}").as_bytes());
    h[..8].try_into().unwrap()
}

fn ix_data<T: BorshSerialize>(name: &str, args: &T) -> Vec<u8> {
    let mut d = sighash(name).to_vec();
    d.extend(borsh::to_vec(args).unwrap());
    d
}

fn pda(seeds: &[&[u8]]) -> Pubkey {
    Pubkey::find_program_address(seeds, &program_id()).0
}

fn config_pda() -> Pubkey {
    pda(&[b"config"])
}
fn allowed_pda(mint: &Pubkey) -> Pubkey {
    pda(&[b"mint", mint.as_ref()])
}
fn deal_pda(seller: &Pubkey, id: u64) -> Pubkey {
    pda(&[b"deal", seller.as_ref(), &id.to_le_bytes()])
}
fn vault_pda(deal: &Pubkey) -> Pubkey {
    pda(&[b"vault", deal.as_ref()])
}
fn otc_pda(maker: &Pubkey, id: u64) -> Pubkey {
    pda(&[b"otc", maker.as_ref(), &id.to_le_bytes()])
}
fn otc_vault_pda(offer: &Pubkey) -> Pubkey {
    pda(&[b"otc_vault", offer.as_ref()])
}
fn rep_pda(owner: &Pubkey) -> Pubkey {
    pda(&[b"rep", owner.as_ref()])
}

fn w(k: Pubkey) -> AccountMeta {
    AccountMeta::new(k, false)
}
fn r(k: Pubkey) -> AccountMeta {
    AccountMeta::new_readonly(k, false)
}
fn ws(k: Pubkey) -> AccountMeta {
    AccountMeta::new(k, true)
}
fn rs(k: Pubkey) -> AccountMeta {
    AccountMeta::new_readonly(k, true)
}

#[derive(BorshSerialize)]
struct ConfigParams {
    arbiter: [u8; 32],
    treasury: [u8; 32],
    fee_bps: u16,
    otc_fee_bps: u16,
    dispute_fee_bps: u16,
}

#[derive(BorshSerialize)]
struct UpdateConfigParams {
    admin: [u8; 32],
    arbiter: [u8; 32],
    treasury: [u8; 32],
    fee_bps: u16,
    otc_fee_bps: u16,
    dispute_fee_bps: u16,
}

#[derive(BorshSerialize)]
struct MintParams {
    min_amount: u64,
    max_amount: u64,
    min_fee: u64,
    dispute_min_fee: u64,
    enabled: bool,
}

#[derive(BorshSerialize, Clone, Copy)]
enum FeeMode {
    Seller,
    Buyer,
    Split,
}

#[derive(BorshDeserialize, Debug, Default)]
struct Reputation {
    owner: [u8; 32],
    deals_as_seller: u32,
    deals_as_buyer: u32,
    otc_trades: u32,
    disputes_won: u32,
    disputes_lost: u32,
    volume: u64,
    fees_paid: u64,
    first_activity: i64,
    last_activity: i64,
    bump: u8,
}

// ----------------------------- Ambiente de teste -----------------------------

struct Env {
    svm: LiteSVM,
    admin: Keypair,
    arbiter: Keypair,
    treasury: Keypair,
    usdc: Pubkey,
    usdt: Pubkey,
    meme: Pubkey,
    next_token_account: u64,
}

fn pack_mint(decimals: u8) -> Vec<u8> {
    let mut d = vec![0u8; 82];
    d[36..44].copy_from_slice(&0u64.to_le_bytes()); // supply (não importa nos testes)
    d[44] = decimals;
    d[45] = 1; // is_initialized
    d
}

fn pack_token_account(mint: &Pubkey, owner: &Pubkey, amount: u64) -> Vec<u8> {
    let mut d = vec![0u8; 165];
    d[0..32].copy_from_slice(mint.as_ref());
    d[32..64].copy_from_slice(owner.as_ref());
    d[64..72].copy_from_slice(&amount.to_le_bytes());
    d[108] = 1; // state = Initialized
    d
}

impl Env {
    fn new() -> Self {
        let mut svm = LiteSVM::new();
        let so = std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"), "/../target/deploy/trato.so"))
            .expect("compile o programa antes (target/deploy/trato.so)");
        svm.add_program(program_id(), &so).unwrap();

        let admin = Keypair::new();
        let arbiter = Keypair::new();
        let treasury = Keypair::new();
        for k in [&admin, &arbiter, &treasury] {
            svm.airdrop(&k.pubkey(), 100_000_000_000).unwrap();
        }

        // Define o admin como autoridade de upgrade do programa (como num deploy real).
        let programdata = Pubkey::find_program_address(&[program_id().as_ref()], &loader_v3()).0;
        let mut acc = svm.get_account(&programdata).unwrap();
        acc.data[12] = 1;
        acc.data[13..45].copy_from_slice(admin.pubkey().as_ref());
        svm.set_account(programdata, acc).unwrap();

        let mut env = Env {
            svm,
            admin,
            arbiter,
            treasury,
            usdc: Pubkey::new_unique(),
            usdt: Pubkey::new_unique(),
            meme: Pubkey::new_unique(),
            next_token_account: 0,
        };
        for (m, dec) in [(env.usdc, 6u8), (env.usdt, 6), (env.meme, 9)] {
            env.set_raw(m, token_program(), pack_mint(dec));
        }
        env
    }

    fn set_raw(&mut self, key: Pubkey, owner: Pubkey, data: Vec<u8>) {
        let lamports = self.svm.minimum_balance_for_rent_exemption(data.len());
        self.svm
            .set_account(key, Account { lamports, data, owner, executable: false, rent_epoch: 0 })
            .unwrap();
    }

    fn user(&mut self) -> Keypair {
        let k = Keypair::new();
        self.svm.airdrop(&k.pubkey(), 10_000_000_000).unwrap();
        k
    }

    fn token_account(&mut self, mint: &Pubkey, owner: &Pubkey, amount: u64) -> Pubkey {
        self.next_token_account += 1;
        let key = Pubkey::new_unique();
        self.set_raw(key, token_program(), pack_token_account(mint, owner, amount));
        key
    }

    fn balance(&self, token_account: &Pubkey) -> u64 {
        let a = self.svm.get_account(token_account).unwrap();
        u64::from_le_bytes(a.data[64..72].try_into().unwrap())
    }

    fn exists(&self, key: &Pubkey) -> bool {
        self.svm.get_account(key).map(|a| a.lamports > 0).unwrap_or(false)
    }

    fn rep(&self, owner: &Pubkey) -> Reputation {
        let a = self.svm.get_account(&rep_pda(owner)).unwrap();
        Reputation::deserialize(&mut &a.data[8..]).unwrap()
    }

    fn now(&self) -> i64 {
        self.svm.get_sysvar::<Clock>().unix_timestamp
    }

    fn warp(&mut self, secs: i64) {
        let mut c = self.svm.get_sysvar::<Clock>();
        c.unix_timestamp += secs;
        c.slot += 1;
        self.svm.set_sysvar(&c);
        self.svm.expire_blockhash();
    }

    /// Envia uma instrução. Retorna Ok ou os logs do erro.
    fn send(&mut self, ix: Instruction, signers: &[&Keypair]) -> Result<(), String> {
        let payer = signers[0].pubkey();
        let msg = Message::new(&[ix], Some(&payer));
        let tx = Transaction::new(signers, msg, self.svm.latest_blockhash());
        let res = self.svm.send_transaction(tx);
        self.svm.expire_blockhash();
        if std::env::var("SHOW_CU").is_ok() {
            if let Ok(meta) = &res {
                eprintln!("CU {}", meta.compute_units_consumed);
            }
        }
        res.map(|_| ()).map_err(|e| format!("{:?}\n{}", e.err, e.meta.logs.join("\n")))
    }

    fn expect_err(&mut self, ix: Instruction, signers: &[&Keypair], code: &str) {
        match self.send(ix, signers) {
            Ok(()) => panic!("esperava erro {code}, mas a transação passou"),
            Err(logs) => assert!(logs.contains(code), "esperava {code}, veio:\n{logs}"),
        }
    }

    // ------------------------- Instruções -------------------------

    fn ix_init_config(&self, signer: &Pubkey, fee: u16, otc_fee: u16, dispute_fee: u16) -> Instruction {
        let programdata = Pubkey::find_program_address(&[program_id().as_ref()], &loader_v3()).0;
        Instruction {
            program_id: program_id(),
            accounts: vec![ws(*signer), w(config_pda()), r(program_id()), r(programdata), r(system_program())],
            data: ix_data(
                "initialize_config",
                &ConfigParams {
                    arbiter: self.arbiter.pubkey().to_bytes(),
                    treasury: self.treasury.pubkey().to_bytes(),
                    fee_bps: fee,
                    otc_fee_bps: otc_fee,
                    dispute_fee_bps: dispute_fee,
                },
            ),
        }
    }

    fn ix_update_config(&self, signer: &Pubkey, fee: u16) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![rs(*signer), w(config_pda())],
            data: ix_data(
                "update_config",
                &UpdateConfigParams {
                    admin: self.admin.pubkey().to_bytes(),
                    arbiter: self.arbiter.pubkey().to_bytes(),
                    treasury: self.treasury.pubkey().to_bytes(),
                    fee_bps: fee,
                    otc_fee_bps: 50,
                    dispute_fee_bps: 200,
                },
            ),
        }
    }

    fn ix_set_paused(&self, paused: bool) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![rs(self.admin.pubkey()), w(config_pda())],
            data: ix_data("set_paused", &paused),
        }
    }

    fn ix_upsert_mint(&self, mint: &Pubkey, p: MintParams) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(self.admin.pubkey()),
                r(config_pda()),
                r(*mint),
                w(allowed_pda(mint)),
                r(system_program()),
            ],
            data: ix_data("upsert_mint", &p),
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn ix_create_deal(
        &self,
        seller: &Pubkey,
        id: u64,
        buyer: Option<Pubkey>,
        amount: u64,
        mode: FeeMode,
        delivery: i64,
        review: i64,
    ) -> Instruction {
        let deal = deal_pda(seller, id);
        let args = (id, buyer.map(|b| b.to_bytes()), amount, mode, [7u8; 32], delivery, review);
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(*seller),
                r(config_pda()),
                r(allowed_pda(&self.usdc)),
                r(self.usdc),
                w(deal),
                w(vault_pda(&deal)),
                w(rep_pda(seller)),
                r(token_program()),
                r(system_program()),
            ],
            data: ix_data("create_deal", &args),
        }
    }

    fn ix_fund(&self, buyer: &Pubkey, deal: &Pubkey, buyer_ta: &Pubkey) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(*buyer),
                r(config_pda()),
                w(*deal),
                r(self.usdc),
                w(vault_pda(deal)),
                w(*buyer_ta),
                w(rep_pda(buyer)),
                r(token_program()),
                r(system_program()),
            ],
            data: sighash("fund_deal").to_vec(),
        }
    }

    fn ix_seller_simple(&self, name: &str, seller: &Pubkey, deal: &Pubkey) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![rs(*seller), w(*deal)],
            data: sighash(name).to_vec(),
        }
    }

    fn ix_cancel(&self, seller: &Pubkey, deal: &Pubkey, seller_ta: &Pubkey) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(*seller),
                w(*deal),
                w(vault_pda(deal)),
                r(self.usdc),
                w(*seller_ta),
                r(token_program()),
            ],
            data: sighash("cancel_deal").to_vec(),
        }
    }

    fn ix_dispute(&self, who: &Pubkey, deal: &Pubkey) -> Instruction {
        Instruction {
            program_id: program_id(),
            accounts: vec![rs(*who), w(*deal)],
            data: sighash("open_dispute").to_vec(),
        }
    }

    fn ix_settle(&self, name: &str, data_tail: Vec<u8>, authority: &Pubkey, d: &DealCtx) -> Instruction {
        let mut data = sighash(name).to_vec();
        data.extend(data_tail);
        Instruction {
            program_id: program_id(),
            accounts: vec![
                rs(*authority),
                r(config_pda()),
                w(d.deal),
                w(d.seller),
                r(allowed_pda(&self.usdc)),
                r(self.usdc),
                w(vault_pda(&d.deal)),
                w(d.seller_ta),
                w(d.buyer_ta),
                w(d.treasury_ta),
                w(rep_pda(&d.seller)),
                w(rep_pda(&d.buyer)),
                r(token_program()),
            ],
            data,
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn ix_create_otc(
        &self,
        maker: &Pubkey,
        id: u64,
        offer_mint: &Pubkey,
        ask_mint: &Pubkey,
        maker_offer_ta: &Pubkey,
        taker: Option<Pubkey>,
        offer_amount: u64,
        ask_amount: u64,
        duration: i64,
    ) -> Instruction {
        let offer = otc_pda(maker, id);
        // Contas opcionais ausentes são passadas como o próprio program id (convenção Anchor).
        let opt = |m: &Pubkey| {
            if *m == self.usdc || *m == self.usdt {
                r(allowed_pda(m))
            } else {
                r(program_id())
            }
        };
        let args = (id, taker.map(|t| t.to_bytes()), offer_amount, ask_amount, duration);
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(*maker),
                r(config_pda()),
                r(*offer_mint),
                r(*ask_mint),
                opt(offer_mint),
                opt(ask_mint),
                w(offer),
                w(otc_vault_pda(&offer)),
                w(*maker_offer_ta),
                w(rep_pda(maker)),
                r(token_program()),
                r(system_program()),
            ],
            data: ix_data("create_otc", &args),
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn ix_take_otc(
        &self,
        taker: &Pubkey,
        maker: &Pubkey,
        id: u64,
        offer_mint: &Pubkey,
        ask_mint: &Pubkey,
        taker_offer_ta: &Pubkey,
        taker_ask_ta: &Pubkey,
        maker_ask_ta: &Pubkey,
        treasury_ta: &Pubkey,
    ) -> Instruction {
        let offer = otc_pda(maker, id);
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(*taker),
                r(config_pda()),
                w(offer),
                w(*maker),
                r(*offer_mint),
                r(*ask_mint),
                w(otc_vault_pda(&offer)),
                w(*taker_offer_ta),
                w(*taker_ask_ta),
                w(*maker_ask_ta),
                w(*treasury_ta),
                w(rep_pda(taker)),
                w(rep_pda(maker)),
                r(token_program()),
                r(system_program()),
            ],
            data: sighash("take_otc").to_vec(),
        }
    }

    fn ix_cancel_otc(&self, maker: &Pubkey, id: u64, offer_mint: &Pubkey, maker_offer_ta: &Pubkey) -> Instruction {
        let offer = otc_pda(maker, id);
        Instruction {
            program_id: program_id(),
            accounts: vec![
                ws(*maker),
                w(offer),
                r(*offer_mint),
                w(otc_vault_pda(&offer)),
                w(*maker_offer_ta),
                r(token_program()),
            ],
            data: sighash("cancel_otc").to_vec(),
        }
    }
}

struct DealCtx {
    seller_kp: Keypair,
    buyer_kp: Keypair,
    seller: Pubkey,
    buyer: Pubkey,
    deal: Pubkey,
    seller_ta: Pubkey,
    buyer_ta: Pubkey,
    treasury_ta: Pubkey,
}

/// Ambiente configurado: taxa 1%, OTC 0,5%, disputa 2%; USDC e USDT aprovados
/// (mín. US$ 1, máx. US$ 500, taxa mínima US$ 0,25, taxa mínima de disputa US$ 0,50).
fn setup() -> Env {
    let mut env = Env::new();
    let admin = env.admin.insecure_clone();
    let ix = env.ix_init_config(&admin.pubkey(), 100, 50, 200);
    env.send(ix, &[&admin]).unwrap();
    for m in [env.usdc, env.usdt] {
        let ix = env.ix_upsert_mint(
            &m,
            MintParams { min_amount: USD, max_amount: 500 * USD, min_fee: USD / 4, dispute_min_fee: USD / 2, enabled: true },
        );
        env.send(ix, &[&admin]).unwrap();
    }
    env
}

/// Cria (e opcionalmente paga) um negócio de `amount` com o modo de taxa dado.
fn new_deal(env: &mut Env, id: u64, amount: u64, mode: FeeMode, fund: bool) -> DealCtx {
    let seller_kp = env.user();
    let buyer_kp = env.user();
    let (seller, buyer) = (seller_kp.pubkey(), buyer_kp.pubkey());
    let usdc = env.usdc;
    let treasury = env.treasury.pubkey();
    let seller_ta = env.token_account(&usdc, &seller, 0);
    let buyer_ta = env.token_account(&usdc, &buyer, 1_000 * USD);
    let treasury_ta = env.token_account(&usdc, &treasury, 0);
    let ix = env.ix_create_deal(&seller, id, Some(buyer), amount, mode, 7 * DAY, 3 * DAY);
    env.send(ix, &[&seller_kp]).unwrap();
    let deal = deal_pda(&seller, id);
    if fund {
        let ix = env.ix_fund(&buyer, &deal, &buyer_ta);
        env.send(ix, &[&buyer_kp]).unwrap();
    }
    DealCtx { seller_kp, buyer_kp, seller, buyer, deal, seller_ta, buyer_ta, treasury_ta }
}

// =============================================================================
// Testes
// =============================================================================

#[test]
fn only_upgrade_authority_can_initialize() {
    let mut env = Env::new();
    let attacker = env.user();
    let ix = env.ix_init_config(&attacker.pubkey(), 100, 50, 200);
    env.expect_err(ix, &[&attacker], "Unauthorized");
    let admin = env.admin.insecure_clone();
    let ix = env.ix_init_config(&admin.pubkey(), 100, 50, 200);
    env.send(ix, &[&admin]).unwrap();
}

#[test]
fn fee_cap_is_enforced() {
    let mut env = Env::new();
    let admin = env.admin.insecure_clone();
    let ix = env.ix_init_config(&admin.pubkey(), 201, 50, 200);
    env.expect_err(ix, &[&admin], "FeeTooHigh");
    let ix = env.ix_init_config(&admin.pubkey(), 100, 50, 200);
    env.send(ix, &[&admin]).unwrap();
    let ix = env.ix_update_config(&admin.pubkey(), 500);
    env.expect_err(ix, &[&admin], "FeeTooHigh");
    let stranger = env.user();
    let ix = env.ix_update_config(&stranger.pubkey(), 150);
    env.expect_err(ix, &[&stranger], "Unauthorized");
}

#[test]
fn happy_path_seller_pays_fee() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    assert_eq!(env.balance(&vault_pda(&d.deal)), 100 * USD);
    assert_eq!(env.balance(&d.buyer_ta), 900 * USD);

    let ix = env.ix_seller_simple("mark_delivered", &d.seller, &d.deal);
    env.send(ix, &[&d.seller_kp]).unwrap();
    let ix = env.ix_settle("release", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();

    assert_eq!(env.balance(&d.seller_ta), 99 * USD);
    assert_eq!(env.balance(&d.treasury_ta), USD);
    assert!(!env.exists(&d.deal), "conta do negócio deveria estar fechada");
    assert!(!env.exists(&vault_pda(&d.deal)), "cofre deveria estar fechado");

    let s = env.rep(&d.seller);
    assert_eq!((s.deals_as_seller, s.volume, s.fees_paid), (1, 100 * USD, USD));
    let b = env.rep(&d.buyer);
    assert_eq!((b.deals_as_buyer, b.fees_paid), (1, 0));
}

#[test]
fn buyer_and_split_fee_modes() {
    let mut env = setup();
    // Comprador paga: deposita 101, vendedor recebe 100 limpos.
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Buyer, true);
    assert_eq!(env.balance(&d.buyer_ta), 899 * USD);
    let ix = env.ix_settle("release", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), 100 * USD);
    assert_eq!(env.balance(&d.treasury_ta), USD);

    // Dividido com taxa ímpar: 1% de 33,333333 = 0,333333 -> comprador 0,166666, vendedor 0,166667
    let amount = 33_333_333;
    let d = new_deal(&mut env, 2, amount, FeeMode::Split, true);
    assert_eq!(env.balance(&d.buyer_ta), 1_000 * USD - amount - 166_666);
    let ix = env.ix_settle("release", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), amount - 166_667);
    assert_eq!(env.balance(&d.treasury_ta), 333_333);
}

#[test]
fn minimum_fee_applies_to_small_deals() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 10 * USD, FeeMode::Seller, true);
    let ix = env.ix_settle("release", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), 10 * USD - USD / 4);
    assert_eq!(env.balance(&d.treasury_ta), USD / 4);
}

#[test]
fn only_buyer_can_release() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    let ix = env.ix_settle("release", vec![], &d.seller, &d);
    env.expect_err(ix, &[&d.seller_kp], "Unauthorized");
    let thief = env.user();
    let ix = env.ix_settle("release", vec![], &thief.pubkey(), &d);
    env.expect_err(ix, &[&thief], "Unauthorized");
}

#[test]
fn seller_claims_after_review_window() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    // Sem entrega marcada, não pode reivindicar
    let ix = env.ix_settle("claim_after_review", vec![], &d.seller, &d);
    env.expect_err(ix, &[&d.seller_kp], "InvalidState");

    let ix = env.ix_seller_simple("mark_delivered", &d.seller, &d.deal);
    env.send(ix, &[&d.seller_kp]).unwrap();
    let ix = env.ix_settle("claim_after_review", vec![], &d.seller, &d);
    env.expect_err(ix, &[&d.seller_kp], "TooEarly");

    env.warp(3 * DAY + 1);
    // Depois do prazo, o comprador não pode mais abrir disputa
    let ix = env.ix_dispute(&d.buyer, &d.deal);
    env.expect_err(ix, &[&d.buyer_kp], "TooLate");

    let ix = env.ix_settle("claim_after_review", vec![], &d.seller, &d);
    env.send(ix, &[&d.seller_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), 99 * USD);
}

#[test]
fn buyer_refund_after_delivery_deadline_has_no_fee() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Buyer, true);
    let ix = env.ix_settle("refund_after_deadline", vec![], &d.buyer, &d);
    env.expect_err(ix, &[&d.buyer_kp], "TooEarly");
    env.warp(7 * DAY + 1);
    let ix = env.ix_settle("refund_after_deadline", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.buyer_ta), 1_000 * USD, "comprador recebe tudo, inclusive a parte da taxa");
    assert_eq!(env.balance(&d.treasury_ta), 0);
    assert!(!env.exists(&d.deal));
}

#[test]
fn seller_refund_returns_everything() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 50 * USD, FeeMode::Split, true);
    let ix = env.ix_settle("seller_refund", vec![], &d.seller, &d);
    env.send(ix, &[&d.seller_kp]).unwrap();
    assert_eq!(env.balance(&d.buyer_ta), 1_000 * USD);
    assert_eq!(env.balance(&d.treasury_ta), 0);
}

#[test]
fn dispute_resolved_by_arbiter() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    let ix = env.ix_dispute(&d.buyer, &d.deal);
    env.send(ix, &[&d.buyer_kp]).unwrap();

    // Ninguém além do árbitro resolve
    let ix = env.ix_settle("resolve_dispute", 7_000u16.to_le_bytes().to_vec(), &d.seller, &d);
    env.expect_err(ix, &[&d.seller_kp], "Unauthorized");
    // Durante a disputa não dá para reivindicar por prazo
    let ix = env.ix_settle("claim_after_review", vec![], &d.seller, &d);
    env.expect_err(ix, &[&d.seller_kp], "InvalidState");

    let arbiter = env.arbiter.insecure_clone();
    let ix = env.ix_settle("resolve_dispute", 7_000u16.to_le_bytes().to_vec(), &arbiter.pubkey(), &d);
    env.send(ix, &[&arbiter]).unwrap();

    // 70% ao vendedor: 70 - 0,70 de taxa = 69,30
    // Comprador: 30 - 2 (taxa de disputa de 2%, pois perdeu) = 28
    // Tesouraria: 0,70 + 2 = 2,70
    assert_eq!(env.balance(&d.seller_ta), 69_300_000);
    assert_eq!(env.balance(&d.buyer_ta), 900 * USD + 28 * USD);
    assert_eq!(env.balance(&d.treasury_ta), 2_700_000);
    assert_eq!(env.rep(&d.seller).disputes_won, 1);
    assert_eq!(env.rep(&d.buyer).disputes_lost, 1);
    assert!(!env.exists(&d.deal));
}

#[test]
fn party_can_concede_a_dispute() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    let ix = env.ix_dispute(&d.seller, &d.deal);
    env.send(ix, &[&d.seller_kp]).unwrap();
    // Comprador cede e libera normalmente (sem taxa de disputa)
    let ix = env.ix_settle("release", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), 99 * USD);
    assert_eq!(env.balance(&d.treasury_ta), USD);
}

#[test]
fn stale_dispute_splits_50_50_without_fees() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Buyer, true);
    let ix = env.ix_dispute(&d.buyer, &d.deal);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    let ix = env.ix_settle("resolve_stale_dispute", vec![], &d.buyer, &d);
    env.expect_err(ix, &[&d.buyer_kp], "TooEarly");
    env.warp(30 * DAY + 1);
    let ix = env.ix_settle("resolve_stale_dispute", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), 50 * USD);
    // comprador depositou 101 (com a taxa) e recebe 51 de volta
    assert_eq!(env.balance(&d.buyer_ta), 899 * USD + 51 * USD);
    assert_eq!(env.balance(&d.treasury_ta), 0);
}

#[test]
fn pause_blocks_new_activity_but_not_refunds() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    let pending = new_deal(&mut env, 2, 100 * USD, FeeMode::Seller, false);
    let admin = env.admin.insecure_clone();
    let ix = env.ix_set_paused(true);
    env.send(ix, &[&admin]).unwrap();

    let ix = env.ix_create_deal(&d.seller, 3, None, 10 * USD, FeeMode::Seller, DAY, DAY);
    env.expect_err(ix, &[&d.seller_kp], "Paused");
    let ix = env.ix_fund(&pending.buyer, &pending.deal, &pending.buyer_ta);
    env.expect_err(ix, &[&pending.buyer_kp], "Paused");

    // Saídas continuam funcionando
    let ix = env.ix_settle("seller_refund", vec![], &d.seller, &d);
    env.send(ix, &[&d.seller_kp]).unwrap();
    let ix = env.ix_cancel(&pending.seller, &pending.deal, &pending.seller_ta);
    env.send(ix, &[&pending.seller_kp]).unwrap();
    assert!(!env.exists(&pending.deal) && !env.exists(&vault_pda(&pending.deal)));

    let ix = env.ix_set_paused(false);
    env.send(ix, &[&admin]).unwrap();
}

#[test]
fn deal_validation_rules() {
    let mut env = setup();
    let seller = env.user();
    let s = seller.pubkey();
    // Valor fora dos limites (máx. US$ 500 no beta)
    let ix = env.ix_create_deal(&s, 1, None, 501 * USD, FeeMode::Seller, DAY, DAY);
    env.expect_err(ix, &[&seller], "AmountOutOfRange");
    let ix = env.ix_create_deal(&s, 1, None, USD / 2, FeeMode::Seller, DAY, DAY);
    env.expect_err(ix, &[&seller], "AmountOutOfRange");
    // Prazo curto demais e longo demais
    let ix = env.ix_create_deal(&s, 1, None, 10 * USD, FeeMode::Seller, HOUR - 1, DAY);
    env.expect_err(ix, &[&seller], "InvalidWindow");
    let ix = env.ix_create_deal(&s, 1, None, 10 * USD, FeeMode::Seller, DAY, 31 * DAY);
    env.expect_err(ix, &[&seller], "InvalidWindow");
    // Comprador igual ao vendedor
    let ix = env.ix_create_deal(&s, 1, Some(s), 10 * USD, FeeMode::Seller, DAY, DAY);
    env.expect_err(ix, &[&seller], "SameParty");
}

#[test]
fn open_link_anyone_can_pay_once() {
    let mut env = setup();
    let seller = env.user();
    let s = seller.pubkey();
    let ix = env.ix_create_deal(&s, 9, None, 20 * USD, FeeMode::Seller, DAY, DAY);
    env.send(ix, &[&seller]).unwrap();
    let deal = deal_pda(&s, 9);
    let usdc = env.usdc;

    // O próprio vendedor não pode pagar
    let own_ta = env.token_account(&usdc, &s, 100 * USD);
    let ix = env.ix_fund(&s, &deal, &own_ta);
    env.expect_err(ix, &[&seller], "SameParty");

    let payer = env.user();
    let p = payer.pubkey();
    let pta = env.token_account(&usdc, &p, 100 * USD);
    let ix = env.ix_fund(&p, &deal, &pta);
    env.send(ix, &[&payer]).unwrap();
    assert_eq!(env.balance(&pta), 80 * USD);

    // Ninguém paga duas vezes
    let other = env.user();
    let o = other.pubkey();
    let ota = env.token_account(&usdc, &o, 100 * USD);
    let ix = env.ix_fund(&o, &deal, &ota);
    env.expect_err(ix, &[&other], "InvalidState");
}

#[test]
fn specific_buyer_is_enforced() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, false);
    let intruder = env.user();
    let usdc = env.usdc;
    let ita = env.token_account(&usdc, &intruder.pubkey(), 500 * USD);
    let ix = env.ix_fund(&intruder.pubkey(), &d.deal, &ita);
    env.expect_err(ix, &[&intruder], "Unauthorized");
}

#[test]
fn cancel_only_before_payment() {
    let mut env = setup();
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, true);
    let ix = env.ix_cancel(&d.seller, &d.deal, &d.seller_ta);
    env.expect_err(ix, &[&d.seller_kp], "InvalidState");
}

#[test]
fn rejects_unapproved_mint() {
    let mut env = setup();
    let admin = env.admin.insecure_clone();
    let usdc = env.usdc;
    let ix = env.ix_upsert_mint(
        &usdc,
        MintParams { min_amount: USD, max_amount: 500 * USD, min_fee: USD / 4, dispute_min_fee: USD / 2, enabled: false },
    );
    env.send(ix, &[&admin]).unwrap();
    let seller = env.user();
    let ix = env.ix_create_deal(&seller.pubkey(), 1, None, 10 * USD, FeeMode::Seller, DAY, DAY);
    env.expect_err(ix, &[&seller], "MintNotAllowed");
    // Mínimo de taxa não pode ser >= valor mínimo
    let ix = env.ix_upsert_mint(
        &usdc,
        MintParams { min_amount: USD, max_amount: 500 * USD, min_fee: USD, dispute_min_fee: USD / 2, enabled: true },
    );
    env.expect_err(ix, &[&admin], "InvalidParameter");
}

// ----------------------------- OTC -----------------------------

#[test]
fn otc_swap_fee_on_ask_side() {
    let mut env = setup();
    let maker = env.user();
    let taker = env.user();
    let (m, t) = (maker.pubkey(), taker.pubkey());
    let (usdc, meme, treasury) = (env.usdc, env.meme, env.treasury.pubkey());
    let maker_meme = env.token_account(&meme, &m, 1_000_000_000_000);
    let maker_usdc = env.token_account(&usdc, &m, 0);
    let taker_meme = env.token_account(&meme, &t, 0);
    let taker_usdc = env.token_account(&usdc, &t, 200 * USD);
    let treasury_usdc = env.token_account(&usdc, &treasury, 0);

    // Maker vende 1.000 MEME (9 casas) por 100 USDC
    let ix = env.ix_create_otc(&m, 1, &meme, &usdc, &maker_meme, None, 1_000_000_000_000, 100 * USD, DAY);
    env.send(ix, &[&maker]).unwrap();
    let offer = otc_pda(&m, 1);
    assert_eq!(env.balance(&otc_vault_pda(&offer)), 1_000_000_000_000);

    // Conta de tesouraria na moeda errada é recusada
    let treasury_meme = env.token_account(&meme, &treasury, 0);
    let ix = env.ix_take_otc(&t, &m, 1, &meme, &usdc, &taker_meme, &taker_usdc, &maker_usdc, &treasury_meme);
    env.expect_err(ix, &[&taker], "InvalidTreasuryAccount");

    let ix = env.ix_take_otc(&t, &m, 1, &meme, &usdc, &taker_meme, &taker_usdc, &maker_usdc, &treasury_usdc);
    env.send(ix, &[&taker]).unwrap();

    // Taxa OTC 0,5% de 100 = 0,50 (acima do mínimo de 0,25)
    assert_eq!(env.balance(&taker_meme), 1_000_000_000_000);
    assert_eq!(env.balance(&taker_usdc), 100 * USD);
    assert_eq!(env.balance(&maker_usdc), 99_500_000);
    assert_eq!(env.balance(&treasury_usdc), 500_000);
    assert!(!env.exists(&offer) && !env.exists(&otc_vault_pda(&offer)));
    assert_eq!(env.rep(&m).otc_trades, 1);
    assert_eq!(env.rep(&t).otc_trades, 1);
    assert_eq!(env.rep(&m).fees_paid, 500_000);
}

#[test]
fn otc_swap_fee_on_offer_side() {
    let mut env = setup();
    let maker = env.user();
    let taker = env.user();
    let (m, t) = (maker.pubkey(), taker.pubkey());
    let (usdt, meme, treasury) = (env.usdt, env.meme, env.treasury.pubkey());
    // Maker COMPRA token: oferece 200 USDT, pede 5.000 MEME
    let maker_usdt = env.token_account(&usdt, &m, 200 * USD);
    let maker_meme = env.token_account(&meme, &m, 0);
    let taker_usdt = env.token_account(&usdt, &t, 0);
    let taker_meme = env.token_account(&meme, &t, 5_000_000_000_000);
    let treasury_usdt = env.token_account(&usdt, &treasury, 0);

    let ix = env.ix_create_otc(&m, 7, &usdt, &meme, &maker_usdt, Some(t), 200 * USD, 5_000_000_000_000, HOUR);
    env.send(ix, &[&maker]).unwrap();
    let ix = env.ix_take_otc(&t, &m, 7, &usdt, &meme, &taker_usdt, &taker_meme, &maker_meme, &treasury_usdt);
    env.send(ix, &[&taker]).unwrap();
    assert_eq!(env.balance(&maker_meme), 5_000_000_000_000);
    assert_eq!(env.balance(&taker_usdt), 199 * USD); // 0,5% de 200 = 1
    assert_eq!(env.balance(&treasury_usdt), USD);
    assert_eq!(env.rep(&t).fees_paid, USD);
}

#[test]
fn otc_rules_expiry_taker_and_cancel() {
    let mut env = setup();
    let maker = env.user();
    let (m, usdc, meme, treasury) = (maker.pubkey(), env.usdc, env.meme, env.treasury.pubkey());
    let maker_meme = env.token_account(&meme, &m, 10_000);
    let maker_usdc = env.token_account(&usdc, &m, 0);
    let treasury_usdc = env.token_account(&usdc, &treasury, 0);

    // Nenhum lado aprovado -> recusado
    let other_token = Pubkey::new_unique();
    env.set_raw(other_token, token_program(), pack_mint(6));
    let ix = env.ix_create_otc(&m, 1, &meme, &other_token, &maker_meme, None, 10_000, 10 * USD, DAY);
    env.expect_err(ix, &[&maker], "NoQuoteMint");

    // Oferta para um taker específico
    let chosen = env.user();
    let ix = env.ix_create_otc(&m, 2, &meme, &usdc, &maker_meme, Some(chosen.pubkey()), 10_000, 10 * USD, HOUR);
    env.send(ix, &[&maker]).unwrap();

    let stranger = env.user();
    let s = stranger.pubkey();
    let s_meme = env.token_account(&meme, &s, 0);
    let s_usdc = env.token_account(&usdc, &s, 100 * USD);
    let ix = env.ix_take_otc(&s, &m, 2, &meme, &usdc, &s_meme, &s_usdc, &maker_usdc, &treasury_usdc);
    env.expect_err(ix, &[&stranger], "Unauthorized");

    // Expira
    env.warp(HOUR + 1);
    let c = chosen.pubkey();
    let c_meme = env.token_account(&meme, &c, 0);
    let c_usdc = env.token_account(&usdc, &c, 100 * USD);
    let ix = env.ix_take_otc(&c, &m, 2, &meme, &usdc, &c_meme, &c_usdc, &maker_usdc, &treasury_usdc);
    env.expect_err(ix, &[&chosen], "Expired");

    // Só o maker cancela, e recebe tudo de volta
    let ix = env.ix_cancel_otc(&s, 2, &meme, &s_meme);
    assert!(env.send(ix, &[&stranger]).is_err());
    let ix = env.ix_cancel_otc(&m, 2, &meme, &maker_meme);
    env.send(ix, &[&maker]).unwrap();
    assert_eq!(env.balance(&maker_meme), 10_000);
    let offer = otc_pda(&m, 2);
    assert!(!env.exists(&offer) && !env.exists(&otc_vault_pda(&offer)));
}

#[test]
fn rent_goes_back_to_seller() {
    let mut env = setup();
    let seller = env.user();
    let s = seller.pubkey();
    let usdc = env.usdc;
    let sta = env.token_account(&usdc, &s, 0);
    let before = env.svm.get_account(&s).unwrap().lamports;
    let ix = env.ix_create_deal(&s, 1, None, 10 * USD, FeeMode::Seller, DAY, DAY);
    env.send(ix, &[&seller]).unwrap();
    let ix = env.ix_cancel(&s, &deal_pda(&s, 1), &sta);
    env.send(ix, &[&seller]).unwrap();
    let after = env.svm.get_account(&s).unwrap().lamports;
    // Só sobra o custo das 2 taxas de rede + o registro de reputação (criado uma vez)
    let rep_rent = env.svm.get_account(&rep_pda(&s)).unwrap().lamports;
    assert_eq!(before - after, 2 * 5_000 + rep_rent);
    let _ = env.now();
}

// ----------------------------- Ataques de "doação" -----------------------------

/// Simula alguém enviando tokens direto para um cofre (sem passar pelo programa).
fn donate(env: &mut Env, vault: &Pubkey, extra: u64) {
    let mut acc = env.svm.get_account(vault).unwrap();
    let cur = u64::from_le_bytes(acc.data[64..72].try_into().unwrap());
    acc.data[64..72].copy_from_slice(&(cur + extra).to_le_bytes());
    env.svm.set_account(*vault, acc).unwrap();
}

#[test]
fn donations_to_vault_cannot_lock_a_deal() {
    let mut env = setup();
    // Doação antes do pagamento: o comprador ainda consegue pagar
    let d = new_deal(&mut env, 1, 100 * USD, FeeMode::Seller, false);
    donate(&mut env, &vault_pda(&d.deal), 1);
    let ix = env.ix_fund(&d.buyer, &d.deal, &d.buyer_ta);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    // Doação depois do pagamento: a liberação continua funcionando
    donate(&mut env, &vault_pda(&d.deal), 3);
    let ix = env.ix_settle("release", vec![], &d.buyer, &d);
    env.send(ix, &[&d.buyer_kp]).unwrap();
    assert_eq!(env.balance(&d.seller_ta), 99 * USD);
    assert_eq!(env.balance(&d.treasury_ta), USD + 4, "sobra vai para a tesouraria");
    assert!(!env.exists(&vault_pda(&d.deal)));

    // Cancelamento com doação também funciona (sobra volta ao vendedor)
    let p = new_deal(&mut env, 2, 100 * USD, FeeMode::Seller, false);
    donate(&mut env, &vault_pda(&p.deal), 5);
    let ix = env.ix_cancel(&p.seller, &p.deal, &p.seller_ta);
    env.send(ix, &[&p.seller_kp]).unwrap();
    assert_eq!(env.balance(&p.seller_ta), 5);
    assert!(!env.exists(&p.deal));
}

#[test]
fn donations_to_otc_vault_cannot_lock_an_offer() {
    let mut env = setup();
    let maker = env.user();
    let taker = env.user();
    let (m, t) = (maker.pubkey(), taker.pubkey());
    let (usdc, meme, treasury) = (env.usdc, env.meme, env.treasury.pubkey());
    let maker_meme = env.token_account(&meme, &m, 1_000);
    let maker_usdc = env.token_account(&usdc, &m, 0);
    let taker_meme = env.token_account(&meme, &t, 0);
    let taker_usdc = env.token_account(&usdc, &t, 100 * USD);
    let treasury_usdc = env.token_account(&usdc, &treasury, 0);
    let ix = env.ix_create_otc(&m, 1, &meme, &usdc, &maker_meme, None, 1_000, 10 * USD, DAY);
    env.send(ix, &[&maker]).unwrap();
    donate(&mut env, &otc_vault_pda(&otc_pda(&m, 1)), 7);
    let ix = env.ix_take_otc(&t, &m, 1, &meme, &usdc, &taker_meme, &taker_usdc, &maker_usdc, &treasury_usdc);
    env.send(ix, &[&taker]).unwrap();
    assert_eq!(env.balance(&taker_meme), 1_007);
}
