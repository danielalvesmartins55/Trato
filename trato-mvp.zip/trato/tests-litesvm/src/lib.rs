//! Crate vazio: os testes ficam em tests/.
